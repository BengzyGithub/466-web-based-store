<html><head><title>Checkout</title></head>
    <body>
    <?php
    //You can edit the styles here and call the class name in the file you are using.
	    echo "<style>
            .h1 {

                padding: 15px;

                background-image: linear-gradient( to top left, rgb(238, 196, 36), rgb(150, 84, 84), rgb(197, 20, 88));

                margin-top: 0px;
                }

            .table_to_right {
                border: 2px solid black;
                float: right;
                background-image: linear-gradient(to bottom right, rgb(38, 196, 236), rgb(240, 96, 96), rgb(83, 72, 236));
                width: 30%;
                height: 3%;
                position: absolute;
                right: 0px;
                top: 0px;
                text-align:center;
                position: auto;
                padding: 15px;
                }

            .submitButtons
                {
                    text-transform: uppercase;
                    padding: 8px;
                    border: 2px solid #0099CC;
                    border-radius: 6px;
                    background-color: yellow;
                }
            .size
                {
                    padding: 6px;
                    border: 2px solid #0099CC;
                    border-radius: 6px;
                }
            .column_separator 
                {
                    background-color: black;
                    transform-origin: top top;
                    display: block;
                    transform: translate(3.1in, -5in) rotate(90deg);  
                    padding: 3px;
                    border-radius: 6px;
                    
                   
                }
                .label
                {
                    text: size 15px;
                    text-transform: lowercase;
                    padding: 8px;
                    border: 2px solid #0099CC;
                    border-radius: 6px;
                    background-color: yellow;
                    height: 17px;
                    width: 150px;
                }
                .Total_to_bottomRight {
                    border: 2px solid black;
                    width: 400px;
                    height: 50px;
                    position: absolute;
                    right: 110px;
                    bottom: 70px;
                    float: right;
                    text: size 15px;
                    background-color: #FD5A5A;
                    margin-top: 500px;
                }

                .prodTable{
                    width: 1000px;
                    margin-right: auto;
                    margin-left:auto;
                    }
                    .prodTable, .prdtd{
                    border-style: ridge;
                    border-color: #424242;
                    }
                    th{
                    font-size: 25px;
                    text-align: left;
                    color: white;
                    border-style: ridge;
                    border-color: #424242;
                    background-color: #2471A3;
                    }
                    .prdtd{
                    font-size: 15px;
                    text-align: center;
                    }

                    .table_to_middleRight {
                        border: 2px solid black;
                        float: right;
                        width: 550px;
                        height: 40px;
                        position: absolute;
                        right: 0px;
                        top: -200px;
                        text: size 15px;
                        background-color: #FD5A5A;
                        margin-top: 300px;
                    }

                    .link1_to_bottomLeft {
                        border: 2px solid black;
                        width: 500px;
                        height: 90px;
                        position: absolute;
                        left: 500px;
                        bottom: 70px;
                        background-color: #FD5A5A;
                    
                    }
                    .link2_to_bottomLeft {
                        border: 2px solid black;
                        width: 500px;
                        height: 90px;
                        position: absolute;
                        left: 20px;
                        bottom: 70px;
                        background-color: #FD5A5A;
                    
                    }

                    .table_to_left {
                        border: 2px solid black;
                        float: left;
                        background-image: linear-gradient(to bottom right, rgb(38, 196, 236), rgb(240, 96, 96), rgb(83, 72, 236));
                        width: 50%;
                        height: 3%;
                        position: absolute;
                        left: 20px;
                        top: 27px;
                        text-align:center;
                        position: auto;
                        padding: 7px;
                        }
                    
	        </style>";//note: the translate(3.1in, -5in) rotate(90deg); first argument = width, second = height(-100 all the way to top)
    ?>
    </body>
</html>
