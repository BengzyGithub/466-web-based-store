- 👋 Hi, I’m Alphonse.
- 👀 I’m interested in ... learning how to creat a game and work in real life
- 🌱 I’m currently learning ... In computer science to be a software developer
- 💞️ I’m looking to collaborate with everyone and make some new friends as well.
- 📫 How to reach me ... banana_fish20  for snapchat.

<!---
BengzyGithub/BengzyGithub is a ✨ special ✨ repository because its `README.md` (this file) appears on your GitHub profile.
You can click the Preview link to take a look at your changes.
--->
